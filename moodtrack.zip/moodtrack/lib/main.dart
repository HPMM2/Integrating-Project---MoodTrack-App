import 'package:flutter/material.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:url_launcher/url_launcher.dart';


void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MyApp());
}


class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'MoodTrack',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF20A8B3)),
      ),
      home: const MyHomePage (title: 'MoodTrack'),
    );
  }
}

class MyHomePage extends StatefulWidget {

  const MyHomePage({super.key, required this.title});

  final String title;

  @override

  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {

  String? selectedEmoji;
  Map<DateTime, Map<String, String>> moodEntries = {};
  TextEditingController _noteController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: const BoxDecoration(
                color: Color(0xFF20A8B3),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text(
                    'Menú',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 24,
                    ),
                  ),
                  const SizedBox(height: 10),
                  CircleAvatar(
                    radius: 30,
                    backgroundColor: Colors.white,
                    child: Image.asset(
                      'assets/cute-anime-profile-pictures-ocsp6rlknshumiuw.jpg',
                      width: 60,
                      height: 60,
                    ),
                  ),
                ],
              ),
            ),
            ListTile(
              leading: const Icon(Icons.calendar_today),
              title: const Text('Calendario de emociones'),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => CalendarScreen(moodEntries: moodEntries)),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.insights),
              title: const Text('Estadísticas'),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const StatsScreen()),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.lightbulb),
              title: const Text('Tips y consejos'),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const TipsScreen()),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.settings),
              title: const Text('Configuración'),
              onTap: () => Navigator.pop(context),
            ),
          ],
        ),
      ),
      appBar: AppBar(
        backgroundColor: const Color(0xFF20A8B3),
        title: Text(widget.title),
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications),
            onPressed: () {},
          ),
        ],
      ),
      body: Column(
        children: [
          // Parte superior azul
          Container(
            color: const Color(0xFF20A8B3),
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Avatar
                Container(
                  width: 80,
                  height: 80,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(40),
                    border: Border.all(color: Colors.white, width: 2),
                    image: const DecorationImage(
                      image: AssetImage("assets/cute-anime-profile-pictures-ocsp6rlknshumiuw.jpg"),
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
                const SizedBox(width: 15),
                // Mensaje de bienvenida
                Expanded(
                  child: Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: const Color(0xAD027B84),
                      borderRadius: BorderRadius.circular(15),
                    ),
                    child: const Text(
                      '¡Hola! 😊\nNos alegra verte feliz y en armonía contigo mismo. 🎉✨ En Mood Track, celebramos cada momento de bienestar.',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),

          // Contenido principal blanco
          Expanded(
            child: Container(
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(45),
                  topRight: Radius.circular(45),
                ),
              ),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: ListView(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  children: [
                    const SizedBox(height: 20),
                    const Center(
                      child: Text(
                        '¿Cómo te sientes hoy?',
                        style: TextStyle(
                          color: Color(0xFF1C4144),
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    const SizedBox(height: 30),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        _buildEmotionOption('😭', 'Super triste'),
                        _buildEmotionOption('😢', 'Triste'),
                        _buildEmotionOption('😐', 'Neutral'),
                        _buildEmotionOption('😊', 'Feliz'),
                        _buildEmotionOption('😄', 'Contento'),
                      ],
                    ),
                    const SizedBox(height: 30),
                    Container(
                      padding: const EdgeInsets.all(15),
                      decoration: BoxDecoration(
                        color: const Color(0x42FED955),
                        borderRadius: BorderRadius.circular(15),
                      ),
                      child: Column(
                        children: [
                          const Text(
                            '¿Por qué? Recuerda que es importante que expreses tú sentir',
                            style: TextStyle(
                              color: Colors.black,
                              fontSize: 11,
                            ),
                          ),
                          const SizedBox(height: 15),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(13),
                              border: Border.all(color: Colors.grey.shade300),
                            ),
                            child: TextField(
                              controller: _noteController,
                              decoration: InputDecoration(
                                hintText: 'Escribe cómo te sientes...',
                                hintStyle: TextStyle(color: Color(0xFFD6CFCF)),
                                border: InputBorder.none,
                              ),
                            ),
                          ),
                          const SizedBox(height: 20),
                          Align(
                            alignment: Alignment.centerRight,
                            child: ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: const Color(0xFF20A8B3),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(20),
                                ),
                              ),
                              onPressed: () {
                              if (selectedEmoji != null && _noteController.text.isNotEmpty) {
                                final today = DateTime(
                                  DateTime.now().year,
                                  DateTime.now().month,
                                  DateTime.now().day,
                                );
                                setState(() {
                                  moodEntries[today] = {
                                    'emoji': selectedEmoji!,
                                    'note': _noteController.text,
                                  };
                                });
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(content: Text('Estado de ánimo guardado')),
                                );
                                _noteController.clear();
                              } else {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(content: Text('Selecciona un emoji y escribe una nota')),
                                );
                              }
                            },
                            child: const Text(
                              'Guardar',
                              style: TextStyle(color: Colors.white),
                            ),
                          ),
                        ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 20),
                  ],
                ),
              ),
            ),
          ),
          Container(
            height: 70,
            color: Colors.white,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                InkWell(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => CalendarScreen(moodEntries: moodEntries)),
                    );
                  },
                  child: _buildBottomNavItem(Icons.calendar_today, 'Calendario'),
                ),
                InkWell(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const StatsScreen()),
                    );
                  },
                  child: _buildBottomNavItem(Icons.insights, 'Estadísticas'),
                ),
                InkWell(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const TipsScreen()),
                    );
                  },
                  child: _buildBottomNavItem(Icons.lightbulb, 'Tips'),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmotionOption(String emoji, String label) {
    final isSelected = selectedEmoji == emoji;

    return GestureDetector(
      onTap: () {
        setState(() {
          selectedEmoji = emoji;
        });
      },
      child: Container(
        padding: const EdgeInsets.all(5),
        decoration: BoxDecoration(
          border: isSelected ? Border.all(color: Colors.blue, width: 3) : null,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Text(
          emoji,
          style: const TextStyle(fontSize: 28),
        ),
      ),
    );
  }

  Widget _buildBottomNavItem(IconData icon, String label) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, size: 30, color: const Color(0xFF20A8B3)),
        const SizedBox(height: 5),
        Text(
          label,
          style: const TextStyle(
            color: Color(0xFF20A8B3),
            fontSize: 12,
          ),
        ),
      ],
    );
  }
}

class CalendarScreen extends StatefulWidget {
  final Map<DateTime, Map<String, String>> moodEntries;

  const CalendarScreen({super.key, required this.moodEntries});

  @override
  State<CalendarScreen> createState() => _CalendarScreenState();
}

class _CalendarScreenState extends State<CalendarScreen> {
  DateTime _justDate(DateTime dt) {
    return DateTime(dt.year, dt.month, dt.day);
  }

  CalendarFormat _calendarFormat = CalendarFormat.month;
  DateTime _focusedDay = DateTime.now();
  DateTime? _selectedDay;

  // Estado y emoji separado del texto de la nota
  final List<Map<String, String>> _moodOptions = [
    {'emoji': '😭', 'mood': 'Super triste'},
    {'emoji': '😢', 'mood': 'Triste'},
    {'emoji': '😐', 'mood': 'Neutral'},
    {'emoji': '😊', 'mood': 'Feliz'},
    {'emoji': '😄', 'mood': 'Contento'},
  ];

  // Función para obtener el mood a partir del emoji
  String _getMoodFromEmoji(String emoji) {
    final match = _moodOptions.firstWhere(
          (option) => option['emoji'] == emoji,
      orElse: () => {'mood': 'Desconocido'},
    );
    return match['mood'] ?? 'Desconocido';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF20A8B3),
        title: const Text('Calendario'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TableCalendar(
              firstDay: DateTime.utc(2020, 1, 1),
              lastDay: DateTime.utc(2030, 12, 31),
              focusedDay: _focusedDay,
              calendarFormat: _calendarFormat,
              selectedDayPredicate: (day) =>
                  isSameDay(_justDate(_selectedDay ?? DateTime.now()), _justDate(day)),
              onDaySelected: (selectedDay, focusedDay) {
                setState(() {
                  _selectedDay = _justDate(selectedDay);
                  _focusedDay = focusedDay;
                });
              },
              onFormatChanged: (format) => setState(() => _calendarFormat = format),
              onPageChanged: (focusedDay) => _focusedDay = focusedDay,
              calendarStyle: CalendarStyle(
                todayDecoration: BoxDecoration(
                  color: const Color(0xFF20A8B3).withOpacity(0.5),
                  shape: BoxShape.circle,
                ),
                selectedDecoration: const BoxDecoration(
                  color: Color(0xFF20A8B3),
                  shape: BoxShape.circle,
                ),
              ),
              headerStyle: HeaderStyle(
                formatButtonVisible: true,
                titleCentered: true,
                formatButtonDecoration: BoxDecoration(
                  color: const Color(0xFF20A8B3),
                  borderRadius: BorderRadius.circular(20),
                ),
                formatButtonTextStyle: const TextStyle(color: Colors.white),
              ),
              calendarBuilders: CalendarBuilders(
                defaultBuilder: (context, day, focusedDay) {
                  final dayKey = _justDate(day);
                  if (widget.moodEntries.containsKey(dayKey)) {
                    String emoji = widget.moodEntries[dayKey]!['emoji'] ?? '';
                    return Center(
                        child: Text(emoji, style: const TextStyle(fontSize: 20)));
                  }
                  return null;
                },
                todayBuilder: (context, day, focusedDay) {
                  final dayKey = _justDate(day);
                  if (widget.moodEntries.containsKey(dayKey)) {
                    String emoji = widget.moodEntries[dayKey]!['emoji'] ?? '';
                    return Container(
                      decoration: BoxDecoration(
                        color: const Color(0xFF20A8B3).withOpacity(0.5),
                        shape: BoxShape.circle,
                      ),
                      child: Center(
                          child: Text(emoji, style: const TextStyle(fontSize: 20))),
                    );
                  }
                  return null;
                },
                selectedBuilder: (context, day, focusedDay) {
                  final dayKey = _justDate(day);
                  if (widget.moodEntries.containsKey(dayKey)) {
                    String emoji = widget.moodEntries[dayKey]!['emoji'] ?? '';
                    return Container(
                      decoration: const BoxDecoration(
                        color: Color(0xFF20A8B3),
                        shape: BoxShape.circle,
                      ),
                      child: Center(
                          child: Text(emoji,
                              style:
                              const TextStyle(fontSize: 20, color: Colors.white))),
                    );
                  }
                  return null;
                },
              ),
            ),
            const SizedBox(height: 20),
            Expanded(
              child: _selectedDay == null
                  ? const Center(child: Text('Selecciona un día con un estado de ánimo'))
                  : widget.moodEntries.containsKey(_justDate(_selectedDay!))
                  ? GestureDetector(
                onTap: () => _showEditMoodDialog(_selectedDay!),
                child: _buildEventItem(
                  widget.moodEntries[_justDate(_selectedDay!)]!['emoji'] ?? '',
                  // Aquí usamos mood si existe, si no, sacamos mood del emoji
                  widget.moodEntries[_justDate(_selectedDay!)]!['mood'] ??
                      _getMoodFromEmoji(widget.moodEntries[_justDate(_selectedDay!)]!['emoji'] ?? ''),
                  _getMoodColor(
                    widget.moodEntries[_justDate(_selectedDay!)]!['mood'] ??
                        _getMoodFromEmoji(widget.moodEntries[_justDate(_selectedDay!)]!['emoji'] ?? ''),
                  ),
                  _selectedDay!,
                ),
              )
                  : GestureDetector(
                onTap: () => _showEditMoodDialog(_selectedDay!),
                child: const Center(
                    child: Text('No hay estado de ánimo. Toca para agregar uno.')),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEventItem(String emoji, String mood, Color color, DateTime date) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8),
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text(
                  emoji,
                  style: const TextStyle(fontSize: 30),
                ),
                const SizedBox(width: 8),
                Text(
                  'Estado de ánimo: $mood',
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text('${date.day}/${date.month}/${date.year}'),
            const SizedBox(height: 8),
            Text(
              'Nota: ${widget.moodEntries[_justDate(date)]?['note'] ?? ''}',
              style: const TextStyle(fontSize: 16),
            ),
          ],
        ),
      ),
    );
  }

  IconData _getMoodIcon(String mood) {
    switch (mood.toLowerCase()) {
      case 'feliz':
        return Icons.sentiment_very_satisfied;
      case 'triste':
        return Icons.sentiment_very_dissatisfied;
      case 'enojado':
        return Icons.sentiment_dissatisfied;
      default:
        return Icons.sentiment_neutral;
    }
  }

  Color _getMoodColor(String mood) {
    switch (mood.toLowerCase()) {
      case 'feliz':
        return Colors.green;
      case 'triste':
        return Colors.blue;
      case 'enojado':
        return Colors.red;
      case 'super triste':
        return Colors.blue.shade900;
      case 'contento':
        return Colors.lightGreen;
      default:
        return Colors.grey;
    }
  }

  void _showEditMoodDialog(DateTime date) {
    final dayKey = _justDate(date);

    // Cargar datos actuales o valores por defecto
    String selectedEmoji = widget.moodEntries[dayKey]?['emoji'] ?? _moodOptions[2]['emoji']!;
    String selectedState = widget.moodEntries[dayKey]?['state'] ?? _moodOptions[2]['mood']!;
    String initialNote = widget.moodEntries[dayKey]?['note'] ?? '';

    final TextEditingController noteController = TextEditingController(text: initialNote);

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Editar estado de ánimo (${date.day}/${date.month}/${date.year})'),
          content: StatefulBuilder(
            builder: (context, setStateDialog) {
              return Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  DropdownButton<String>(
                    value: selectedEmoji,
                    items: _moodOptions.map((option) {
                      return DropdownMenuItem<String>(
                        value: option['emoji'],
                        child: Text('${option['emoji']}  ${option['mood']}'),
                      );
                    }).toList(),
                    onChanged: (value) {
                      if (value != null) {
                        setStateDialog(() {
                          selectedEmoji = value;
                          // Actualizar estado automáticamente al cambiar emoji
                          selectedState = _moodOptions.firstWhere((opt) => opt['emoji'] == value)['mood']!;
                        });
                      }
                    },
                  ),
                  TextField(
                    controller: noteController,
                    decoration: const InputDecoration(labelText: 'Nota'),
                    maxLines: 3,
                  ),
                ],
              );
            },
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancelar'),
            ),
            TextButton(
              onPressed: () {
                setState(() {
                  widget.moodEntries.remove(dayKey);
                });
                Navigator.pop(context);
              },
              child: const Text(
                'Eliminar',
                style: TextStyle(color: Colors.red),
              ),
            ),
            ElevatedButton(
              onPressed: () {
                setState(() {
                  widget.moodEntries[dayKey] = {
                    'emoji': selectedEmoji,
                    'mood': selectedState,
                    'note': noteController.text,
                  };
                });
                Navigator.pop(context);
              },
              child: const Text('Guardar'),
            ),
          ],

        );
      },
    );
  }
}

class StatsScreen extends StatelessWidget {
  const StatsScreen({super.key});

  // Datos falsos de emociones y sus conteos
  final Map<String, int> fakeCounts = const {
    'Super triste': 2,
    'Triste': 4,
    'Neutral': 5,
    'Feliz': 7,
    'Contento': 3,
  };

  @override
  Widget build(BuildContext context) {
    final moodLabels = fakeCounts.keys.toList();

    final maxY = (fakeCounts.values.isEmpty
        ? 1
        : fakeCounts.values.reduce((a, b) => a > b ? a : b))
        .toDouble() + 1;

    List<BarChartGroupData> barGroups = [];
    for (int i = 0; i < moodLabels.length; i++) {
      barGroups.add(
        BarChartGroupData(
          x: i,
          barRods: [
            BarChartRodData(
              toY: fakeCounts[moodLabels[i]]!.toDouble(),
              color: const Color(0xFF20A8B3),
              width: 22,
            )
          ],
          showingTooltipIndicators: [0],
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF20A8B3),
        title: const Text('Estadísticas mensuales'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            const Text(
              'Mensual',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),
            Expanded(
              child: BarChart(
                BarChartData(
                  maxY: maxY,
                  barGroups: barGroups,
                  alignment: BarChartAlignment.spaceAround,
                  titlesData: FlTitlesData(
                    leftTitles: AxisTitles(
                      sideTitles: SideTitles(
                        showTitles: true,
                        interval: 1,
                        reservedSize: 28,
                      ),
                    ),
                    bottomTitles: AxisTitles(
                      sideTitles: SideTitles(
                        showTitles: true,
                        getTitlesWidget: (value, meta) {
                          if (value.toInt() >= 0 &&
                              value.toInt() < moodLabels.length) {
                            return Text(
                              moodLabels[value.toInt()],
                              style: const TextStyle(fontSize: 12),
                            );
                          }
                          return const Text('');
                        },
                      ),
                    ),
                  ),
                  borderData: FlBorderData(show: false),
                  barTouchData: BarTouchData(enabled: true),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class TipsScreen extends StatelessWidget {
  const TipsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF20A8B3),
        title: const Text('Tips y Consejos'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: const [
          TipCard(
            icon: Icons.schedule,
            title: 'Mantén una rutina diaria',
            description:
            'Tener horarios regulares para dormir, comer y trabajar ayuda a equilibrar tus emociones y reducir el estrés.',
            url: 'https://formasfuturo.com.co/blogs/tips/como-hacer-rutina-diaria?srsltid=AfmBOorz13qVmDnieK1J7wgiIfMyPQM8sis81xO0ISxEqterWNA2l0hX',
          ),
          TipCard(
            icon: Icons.favorite,
            title: 'Practica la gratitud',
            description:
            'Escribe tres cosas por las que te sientes agradecido cada día para fomentar pensamientos positivos y bienestar.',
            url: 'https://www.cigna.com/es-us/knowledge-center/hw/cmo-practicar-la-gratitud-abl0225',
          ),
          TipCard(
            icon: Icons.fitness_center,
            title: 'Haz ejercicio diario',
            description:
            'Realiza al menos 30 minutos de actividad física para liberar endorfinas que mejoran tu estado de ánimo y energía.',
            url: 'https://www.tucanaldesalud.com/es/tusaludaldia/articulos/rutina-ejercicios-personas-tiempo',
          ),
          TipCard(
            icon: Icons.self_improvement,
            title: 'Medita o practica mindfulness',
            description:
            'Dedica unos minutos al día para enfocarte en tu respiración y reducir la ansiedad y el estrés.',
            url: 'https://www.psicologiamorali.com/ejercicios-mindfulness/',
          ),
          TipCard(
            icon: Icons.group,
            title: 'Conecta con otras personas',
            description:
            'Pasar tiempo con amigos o familiares fortalece tu red de apoyo emocional y combate la soledad.',
            url: 'https://www.psychologytoday.com/gt/blog/cuando-el-apoyo-social-hace-dano',
          ),
          TipCard(
            icon: Icons.nights_stay,
            title: 'Prioriza un buen sueño',
            description:
            'Dormir entre 7 y 9 horas ayuda a regular tus emociones y mejora tu concentración y energía.',
            url: 'https://www.mayoclinic.org/es/healthy-lifestyle/adult-health/in-depth/sleep/art-20048379',
          ),
          TipCard(
            icon: Icons.water_drop,
            title: 'Mantente hidratado',
            description:
            'Beber suficiente agua influye en tu salud física y mental, ayudando a mantener la concentración y el ánimo.',
            url: 'https://www.osde.com.ar/salud-y-bienestar/7-claves-para-mantener-tu-cuerpo-hidratado-1326.html#:~:text=C%C3%B3mo%20mantener%20una%20buena%20hidrataci%C3%B3n&text=Si%20realiz%C3%A1s%20actividad%20f%C3%ADsica%2C%20aument%C3%A1,deshidrataci%C3%B3n%20por%20su%20efecto%20diur%C3%A9tico.',
          ),
        ],
      ),
    );
  }
}

class TipCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String description;
  final String url;

  const TipCard({
    super.key,
    required this.icon,
    required this.title,
    required this.description,
    required this.url,
  });

  Future<void> _launchURL() async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw 'No se pudo abrir $url';
    }
  }

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: _launchURL,
      child: Card(
        margin: const EdgeInsets.only(bottom: 16),
        elevation: 3,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(icon, color: const Color(0xFF20A8B3), size: 32),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF20A8B3),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      description,
                      style: const TextStyle(fontSize: 15, height: 1.3),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}